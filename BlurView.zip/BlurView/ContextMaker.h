//
//  ContextMaker.h
//  NuevacareClient
//
//  Created by Bhavik  on 25/10/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreImage/CoreImage.h>

@interface ContextMaker : NSObject

+ (CIContext*) makeMeAContext;

@end
