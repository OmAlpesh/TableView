//
//  MenuView.swift
//  NuevacareClient
//
//  Created by Bhavik  on 29/08/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class MenuView: UIView {
    
    //MARK:IBOutlet
    @IBOutlet weak var btnMySchedule     : UIButton!
    @IBOutlet weak var btnNewAvailableShift  : UIButton!
    @IBOutlet weak var btnMyProfile      : UIButton!
    @IBOutlet weak var btnSettings       : UIButton!
    @IBOutlet weak var btnClose          : UIButton!
    
    @IBOutlet weak var lblMySchedule     : UILabel!
    @IBOutlet weak var lblNewAvailableShift  : UILabel!
    @IBOutlet weak var lblMyProfile      : UILabel!
    @IBOutlet weak var lblSettings       : UILabel!
    
    //MARK:Initial Method
    override func awakeFromNib() {
        super.awakeFromNib()
        
         if(Constant.isiPhone_5)
         {
            self.lblMySchedule.font = UIFont(name: lblMySchedule.font.fontName, size: 12)
            self.lblNewAvailableShift.font = UIFont(name: lblNewAvailableShift.font.fontName, size: 12)
            self.lblMyProfile.font = UIFont(name: lblMyProfile.font.fontName, size: 12)
            self.lblSettings.font = UIFont(name: lblSettings.font.fontName, size: 12)
         }
        
        else if(Constant.isiPhone_6_Plus)
        {
            self.lblMySchedule.font = UIFont(name: lblMySchedule.font.fontName, size: 14)
            self.lblNewAvailableShift.font = UIFont(name: lblNewAvailableShift.font.fontName, size: 14)
            self.lblMyProfile.font = UIFont(name: lblMyProfile.font.fontName, size: 14)
            self.lblSettings.font = UIFont(name: lblSettings.font.fontName, size: 14)
        }
        else if Constant.isiPhone_6
        {
            self.lblMySchedule.font = UIFont(name: lblMySchedule.font.fontName, size: 13)
            self.lblNewAvailableShift.font = UIFont(name: lblNewAvailableShift.font.fontName, size: 13)
            self.lblMyProfile.font = UIFont(name: lblMyProfile.font.fontName, size: 13)
            self.lblSettings.font = UIFont(name: lblSettings.font.fontName, size: 13)
        }
    }
    
    //MARK:Click On Close
    @IBAction func clickOnClose(sender:AnyObject)
    {
        NotificationCenter.default.post(name:NSNotification.Name(rawValue: "RemoveTransparentView"), object: nil)
    }
    
    //MARK:Click On My Schedule
    @IBAction func clickOnMySchedule(sender:AnyObject)
    {
        print("Schedule")

        NotificationCenter.default.post(name:NSNotification.Name(rawValue: "RemoveTransparentView"), object: nil)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
           
            let topController = SharedInstance.navigationController?.visibleViewController
            
            if !(topController?.isKind(of:HomeViewController.self))!
            {
                let myScheduleVC = SharedInstance.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                SharedInstance.isNotification = false
                SharedInstance.navigationController?.pushViewController(myScheduleVC, animated: true)
            }
        }
    }
    
    
    //MARK:Click On New Available Shift
    @IBAction func clickOnNewShift(sender:AnyObject)
    {
        print("new shift")
        
        
        NotificationCenter.default.post(name:NSNotification.Name(rawValue: "RemoveTransparentView"), object: nil)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4){
            let topController = SharedInstance.navigationController?.visibleViewController
           if !(topController?.isKind(of:AvailableShiftViewController.self))!
            {
                let newShiftVC = SharedInstance.storyboard?.instantiateViewController(withIdentifier: "AvailableShiftViewController") as! AvailableShiftViewController
                SharedInstance.navigationController?.pushViewController(newShiftVC, animated: true)
          }
        }
     }
    
    //MARK:Click On Profile
    @IBAction func clickOnProfile(sender:AnyObject) {
        print("Profile")
        
        NotificationCenter.default.post(name:NSNotification.Name(rawValue: "RemoveTransparentView"), object: nil)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4){
            let topController = SharedInstance.navigationController?.visibleViewController
            
            if !(topController?.isKind(of:CaregiverProfileViewController.self))!
            {
                let profileVC = SharedInstance.storyboard?.instantiateViewController(withIdentifier: "CaregiverProfileViewController") as! CaregiverProfileViewController
                SharedInstance.navigationController?.pushViewController(profileVC, animated: true)
            }
        }
    }
    
    //MARK:Click On Settings
    @IBAction func clickOnSettings(sender:AnyObject)
    {
        print("Settings")
        
        NotificationCenter.default.post(name:NSNotification.Name(rawValue: "RemoveTransparentView"), object: nil)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4){
            let topController = SharedInstance.navigationController?.visibleViewController
            
            if !(topController?.isKind(of:SettingsViewController.self))!
            {            
                let settingVC = SharedInstance.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController") as! SettingsViewController
                SharedInstance.navigationController?.pushViewController(settingVC, animated: true)
            }
        }
    }
}

