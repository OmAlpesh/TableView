//
//  AvailableShiftViewController.swift
//  NuevacareCaregiver
//
//  Created by alpesh patel on 12/8/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class AvailableShiftViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,TTTAttributedLabelDelegate  {
  
    //IBOutlet
    @IBOutlet weak var btnMenu  : UIButton!
    @IBOutlet weak var lblTitle          :   UILabel!
    @IBOutlet weak var lblNoShiftAvailble :  UILabel!
    @IBOutlet weak var tblAvailableShift   :   UITableView!
    
    //Variable
    var menuView                 : MenuView!
    var arrShiftList = NSMutableArray()
   
    //var availableShiftCell: AvailableShiftCell = AvailableShiftCell()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    //MARK:- View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.lblNoShiftAvailble.isHidden = true
        
        setUPFont()
        setUPTableView()
        
        DispatchQueue.main.async {
            MBProgressHUD.showAdded(to: self.view, animated:true)
        }
        
        AvailableShiftMethod()
    
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        if(SharedInstance.isIntNotIntClick)
        {
            SharedInstance.isIntNotIntClick = false
            arrShiftList.removeAllObjects()
            
            DispatchQueue.main.async {
                MBProgressHUD.showAdded(to: self.view, animated:true)
            }
            AvailableShiftMethod()
        }
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(removeTransparentView),
            name:NSNotification.Name(rawValue: "RemoveTransparentView"),
            object: nil)
        
         NotificationCenter.default.addObserver(self, selector: #selector(RefrashAvailableShift), name: NSNotification.Name(rawValue: "RefreshList"), object: nil)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(true)
        NotificationCenter.default.removeObserver(self)
    }
    
    
    //MARK:Remove Transparent View
    @objc func removeTransparentView(notification: NSNotification){
        
        print(menuView)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.menuView.frame = CGRect(x: self.menuView.frame.origin.x, y: UIScreen.main.bounds.size.height, width: self.menuView.frame.size.width, height: self.menuView.frame.size.height)
        }, completion: {
            (value: Bool) in
            self.btnMenu.isHidden = false
            self.menuView.removeFromSuperview()
            self.view.unBlur()
        })
    }
    
    
    //MARK:- Refresh Available Shift
    func RefrashAvailableShift(notification: NSNotification){
        DispatchQueue.main.async {
            MBProgressHUD.showAdded(to: self.view, animated:true)
        }
       // arrShiftList.removeAllObjects()
        AvailableShiftMethod()
    }

    
    //MARK:SetUpFont
    
    func  setUPFont()
    {
        if(Constant.isiPhone_6_Plus)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 20.0)
            lblNoShiftAvailble.font =  UIFont(name: lblNoShiftAvailble.font.fontName, size: 18.0)
        }
        if(Constant.isiPhone_6)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 18.0)
            lblNoShiftAvailble.font =  UIFont(name: lblNoShiftAvailble.font.fontName, size: 16.0)
        }
        if(Constant.isiPhone_5)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 15.0)
            lblNoShiftAvailble.font =  UIFont(name: lblNoShiftAvailble.font.fontName, size: 13.0)
        }
    }
    
    //MARK:- Set Up TableView
    
    func  setUPTableView(){
        
        tblAvailableShift.register(UINib(nibName: "AvailableShiftCell", bundle: nil), forCellReuseIdentifier: "AvailableShiftCell")
        
        
        tblAvailableShift.tableFooterView = UIView()
        
        tblAvailableShift.estimatedRowHeight = 115
        tblAvailableShift.rowHeight = UITableViewAutomaticDimension
        
    }
    
    //MARK:- WebService Service
    func AvailableShiftMethod()
    {
        
        if !SharedInstance.isReachable {
            Constant.alertView("", strMessage:AlertMessages.kInternetAlertMessage)
            return
        }
        
        let prameter : NSDictionary = [
             "caregiver_id" : UserDefaults.standard.value(forKey: Constant.KEY_CAREGIVERID) as! NSInteger!,
        ]
        
        print(prameter)
        let webserviceOBJ : Webservice = Webservice()
        
        webserviceOBJ.RequestForPost(url: WebserviceURL.kAvailableShiftURL, postData: prameter) { (responseDict, isSuccess) in
            
            print(responseDict)
            
            if isSuccess {
                
                DispatchQueue.main.async {
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
                
               print(responseDict)
                
                if responseDict.value(forKey: "status") as! NSInteger == 1
                {
                    print("Success")
                    
                    UIApplication.shared.applicationIconBadgeNumber = 0
                    
                    self.arrShiftList.removeAllObjects()
                
                    let arrRequestShiftList =  responseDict.value(forKey: "data") as! NSArray
                   
                    if(arrRequestShiftList.count>0)
                    {
                       self.arrShiftList.addObjects(from: arrRequestShiftList as [AnyObject])
                        
                        
                        DispatchQueue.main.async {
                            self.lblNoShiftAvailble.isHidden = true
                            self.tblAvailableShift.isHidden = false

                            self.tblAvailableShift.reloadData()
                        }
                    }
                    
//                    if(self.arrShiftList.count>0)
//                    {
//                        self.lblNoShiftAvailble.isHidden = true
//                        self.tblAvailableShift.isHidden = false
//                        
//                        DispatchQueue.main.async {
//                            self.tblAvailableShift.reloadData()
//                        }
//                    }
//                    else
//                    {
//                        
//                        DispatchQueue.main.async {
//                            self.tblAvailableShift.isHidden = true
//                            self.lblNoShiftAvailble.isHidden = false
//                        }
//                    }
                }
                else if responseDict.value(forKey: "status") as! NSInteger == -1
                {
                    
                    self.arrShiftList.removeAllObjects()

                    DispatchQueue.main.async {
                        self.tblAvailableShift.isHidden = true
                        self.lblNoShiftAvailble.isHidden = false
                    }
                    
//                    if(self.arrShiftList.count>0)
//                    {
//                        self.lblNoShiftAvailble.isHidden = true
//                        self.tblAvailableShift.isHidden = false
//                        
//                        DispatchQueue.main.async {
//                            self.tblAvailableShift.reloadData()
//                        }
//                    }
//                    else
//                    {
//                        
//                        DispatchQueue.main.async {
//                            self.tblAvailableShift.isHidden = true
//                            self.lblNoShiftAvailble.isHidden = false
//                        }
//                    }
                }
                else
                {
                    Constant.alertView("", strMessage: responseDict.value(forKey: "msg") as! String)
                }
            }
            
            DispatchQueue.main.async {
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    
    func InterestedOrNot(shiftId: Int, interested: Int)
    {
        
        if !SharedInstance.isReachable {
            Constant.alertView("", strMessage:AlertMessages.kInternetAlertMessage)
            return
        }
        
        DispatchQueue.main.async {
            
            MBProgressHUD.showAdded(to: self.view, animated:true)
        }
        
        
        let prameter : NSDictionary = [
             "caregiver_id" : UserDefaults.standard.value(forKey: Constant.KEY_CAREGIVERID) as! NSInteger!,
            "interested" : interested,
            "shift_id"  : shiftId
            
        ]
        
        print(prameter)
        
        let webserviceOBJ : Webservice = Webservice()
        
        webserviceOBJ.RequestForPost(url: WebserviceURL.kInterestedOrNotURL, postData: prameter) { (responseDict, isSuccess) in
            
            if isSuccess {
                
                DispatchQueue.main.async {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
                
                print(responseDict)
                
                if responseDict.value(forKey: "status") as! NSInteger == 1
                {
                    print("Success")
                    
                    DispatchQueue.main.async {
                        
                        MBProgressHUD.showAdded(to: self.view, animated:true)
                    }
                
                    self.arrShiftList.removeAllObjects()
                    self.AvailableShiftMethod()
                }
            }
            
            DispatchQueue.main.async {
                
                MBProgressHUD.hide(for: self.view, animated: true)
            }
            
        }
    }

   
    
    //MARK:- UITableViewDelegate & DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrShiftList.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // let cell  = tableView.dequeueReusableCell(withIdentifier: "NotificationCell", for: indexPath as IndexPath) as! NotificationCell
        
       let availableShiftCell = tableView.dequeueReusableCell(withIdentifier: "AvailableShiftCell",for: indexPath as IndexPath) as! AvailableShiftCell
        
        availableShiftCell.selectionStyle = .none
        
        let dict : NSDictionary = arrShiftList.object(at: indexPath.row) as! NSDictionary
        
        availableShiftCell.lblCity.text = dict.value(forKey:"city") as? String
        availableShiftCell.lblAddress.text = String(format:"#%d", dict.value(forKey:"zipcode") as! NSInteger)
        
        let arrSkill:NSArray =  (dict.value(forKey: "skills_needs") as? NSArray)!
        
        
        if arrSkill.count > 1 {
            
            let strSkll1 = arrSkill .object(at: 0) as? String

            
            availableShiftCell.lblSkill1.text = "\(strSkll1!)"
            
            let strSkll2 = arrSkill .object(at: 1) as? String
            
            availableShiftCell.lblSkill2.text = "\(strSkll2!)"
        }
        else
        {
            let strSkll1 = arrSkill .object(at: 0) as? String
            availableShiftCell.lblSkill1.text = "\(strSkll1!)"
            
            availableShiftCell.lblSkill2.isHidden = true
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" //2016-12-09
      
        let shift_start_date = dateFormatter.date(from: (dict.value(forKey: "shift_start_date") as? String)!)
        
        let shift_end_date = dateFormatter.date(from: (dict.value(forKey: "shift_end_date") as? String)!)
        
        dateFormatter.dateFormat = "MMM dd, yyyy"  //April 26, 2016
        
        availableShiftCell.lblDate.text = "\(dateFormatter.string(from: shift_start_date!)) - \(dateFormatter.string(from: shift_end_date!))"
        
        
        
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm:ss"
        //timeFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        
        let shift_start_time = timeFormatter.date(from: (dict.value(forKey: "shift_start_time") as? String)!)
        
        let shift_end_time = timeFormatter.date(from: (dict.value(forKey: "shift_end_time") as? String)!)
        
        timeFormatter.dateFormat = "hh:mm a"
        
        timeFormatter.timeZone = NSTimeZone(name:"America/Los_Angeles") as TimeZone! //NSTimeZone.local

        
        availableShiftCell.lblTime.text = "\(timeFormatter.string(from: shift_start_time!)) - \(timeFormatter.string(from: shift_end_time!))"
        
        
    
        availableShiftCell.btnNotInterested.tag = indexPath.row
        availableShiftCell.btnNotInterested.addTarget(self, action: #selector(self.btnNotInterestedTapped), for: .touchUpInside)
    
        availableShiftCell.btnInterested.tag = indexPath.row
        availableShiftCell.btnInterested.addTarget(self, action: #selector(self.btnInterestedTapped), for: .touchUpInside)
        
        
        if(Constant.isiPhone_6)
        {
            
            availableShiftCell.lblSkill1.font = UIFont(name: (availableShiftCell.lblSkill1.font?.fontName)!, size: 13)
            availableShiftCell.lblSkill2.font = UIFont(name: (availableShiftCell.lblSkill2.font?.fontName)!, size: 13)
        }
        if(Constant.isiPhone_6_Plus)
        {
            availableShiftCell.lblSkill1.font = UIFont(name: (availableShiftCell.lblSkill1.font?.fontName)!, size: 15)
            availableShiftCell.lblSkill2.font = UIFont(name: (availableShiftCell.lblSkill2.font?.fontName)!, size: 15)
        }
        if(Constant.isiPhone_5)
        {
            
            availableShiftCell.lblSkill1.font = UIFont(name: (availableShiftCell.lblSkill1.font?.fontName)!, size: 11)
            availableShiftCell.lblSkill2.font = UIFont(name: (availableShiftCell.lblSkill2.font?.fontName)!, size: 11)
            
        }

        
        return availableShiftCell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        let dict : NSDictionary = arrShiftList.object(at: indexPath.row) as! NSDictionary
        
       
        let storyboard = UIStoryboard(name: "NewStoryBoard", bundle: nil)
        
        let shiftDetails = storyboard.instantiateViewController(withIdentifier: "ShiftDetailsViewController") as! ShiftDetailsViewController
       
        SharedInstance.isNotification = false
        shiftDetails.dictdetails = dict
        
         self.navigationController?.pushViewController(shiftDetails, animated: true)
        
    }
    
    //MARK:- Tap On URL
    private func attributedLabel(label: TTTAttributedLabel!, didSelectLinkWithURL url: NSURL!) {
        
        
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url as URL)
        }
    }
    //MARK:- Action Method
    @IBAction func clickOnMenu(sender:AnyObject) {
        
        self.btnMenu.isHidden = true
        
        self.view.blur(blurRadius:3) //Blur View
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.menuView = Bundle.main.loadNibNamed("MenuView", owner: nil, options: nil)![0] as! MenuView
            let initialframe = self.menuView.frame
            self.menuView.frame = CGRect(x: self.menuView.frame.origin.x, y: UIScreen.main.bounds.size.height, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            
            print(self.menuView.frame)
            
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationDuration(0.4)
            self.menuView.frame = CGRect(x: self.menuView.frame.origin.x, y: initialframe.origin.y, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            UIView.commitAnimations()
            print(self.menuView.frame)
            UIApplication.shared.keyWindow!.addSubview(self.menuView)
        }
    }

    
    
    @IBAction func btnNotifyTapped(_ sender: Any) {
        
        let NotifyVC = SharedInstance.storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
       
        self.navigationController?.pushViewController(NotifyVC, animated: true)
    }

   
    func btnNotInterestedTapped(sender: UIButton)  {
        
         let dict : NSDictionary = arrShiftList.object(at: sender.tag) as! NSDictionary
        
        let alert = UIAlertController(title: "", message: "Are you sure that you are not interested for this shift, as it will not display anymore on your listing?", preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "YES", style: UIAlertActionStyle.default, handler: { action in
            
            self.InterestedOrNot(shiftId: dict.value(forKey: "shift_id") as! intptr_t, interested:0)
        }))
        
        alert.addAction(UIAlertAction(title: "NO", style: UIAlertActionStyle.cancel, handler: { action in
            
            self.dismiss(animated: true, completion: nil)
            
        }))
        
        present(alert, animated: true, completion: nil)
    }
    
    func btnInterestedTapped(sender: UIButton)  {
        
        let dict : NSDictionary = arrShiftList.object(at: sender.tag) as! NSDictionary
        
        let alert = UIAlertController(title: "", message: "Are you sure that you are interested for this shift, as it will not display anymore on your listing?", preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "YES", style: UIAlertActionStyle.default, handler: { action in
            
            self.InterestedOrNot(shiftId: dict.value(forKey: "shift_id") as! intptr_t, interested: 1)
        }))
        
        alert.addAction(UIAlertAction(title: "NO", style: UIAlertActionStyle.cancel, handler: { action in
            
            self.dismiss(animated: true, completion: nil)
            
        }))
        
        present(alert, animated: true, completion: nil)
    
    }
}


class PaddingLabel: UILabel {
    
    @IBInspectable var topInset: CGFloat = 5.0
    @IBInspectable var bottomInset: CGFloat = 5.0
    @IBInspectable var leftInset: CGFloat = 5.0
    @IBInspectable var rightInset: CGFloat = 7.0
    
    override func drawText(in rect: CGRect) {
        let insets = UIEdgeInsets(top: topInset, left: leftInset, bottom: bottomInset, right: rightInset)
        super.drawText(in: UIEdgeInsetsInsetRect(rect, insets))
    }
    
    override var intrinsicContentSize: CGSize {
        get {
            var contentSize = super.intrinsicContentSize
            contentSize.height += topInset + bottomInset
            contentSize.width += leftInset + rightInset
            return contentSize
        }
    }
}
