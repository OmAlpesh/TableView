//
//  NotificationCell.swift
//  NuevacareClient
//
//  Created by Bhavik  on 14/10/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class AvailableShiftCell: UITableViewCell {

    @IBOutlet weak var lblCity : UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblSkill1: PaddingLabel!
    @IBOutlet weak var lblSkill2: PaddingLabel!
    @IBOutlet weak var btnInterested       : UIButton!
    @IBOutlet weak var btnNotInterested    : UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        lblSkill1.layer.borderWidth = 1
        lblSkill1.layer.borderColor = UIColor.init(red: 167.0/255.0, green: 167.0/255.0, blue: 167.0/255.0, alpha: 1.0).cgColor
        lblSkill1.layer.cornerRadius = 8
        
        lblSkill2.layer.borderWidth = 1
        lblSkill2.layer.borderColor = UIColor.init(red: 167.0/255.0, green: 167.0/255.0, blue: 167.0/255.0, alpha: 1.0).cgColor
        lblSkill2.layer.cornerRadius = 8

        
        if(Constant.isiPhone_6)
        {
            lblCity.font = UIFont(name: (lblCity.font?.fontName)!, size: 15)
            lblAddress.font = UIFont(name: (lblCity.font?.fontName)!, size: 15)
            lblDate.font = UIFont(name: (lblCity.font?.fontName)!, size: 15)
            lblTime.font = UIFont(name: (lblCity.font?.fontName)!, size: 15)
           
            
        }
        if(Constant.isiPhone_6_Plus)
        {
            lblCity.font = UIFont(name: (lblCity.font?.fontName)!, size: 16)
            lblAddress.font = UIFont(name: (lblCity.font?.fontName)!, size: 16)
            lblDate.font = UIFont(name: (lblCity.font?.fontName)!, size: 16)
            lblTime.font = UIFont(name: (lblCity.font?.fontName)!, size: 16)
            
        }
        if(Constant.isiPhone_5)
        {
            lblCity.font = UIFont(name: (lblCity.font?.fontName)!, size: 13)
            lblAddress.font = UIFont(name: (lblCity.font?.fontName)!, size: 13)
            lblDate.font = UIFont(name: (lblCity.font?.fontName)!, size: 13)
            lblTime.font = UIFont(name: (lblCity.font?.fontName)!, size: 13)
            
        }

    }

}
